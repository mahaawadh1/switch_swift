import UIKit

var grade: Character = "A"

switch grade {
case "A", "a":
    print("Excellent")
case "B", "b":
    print("Good")
case "C", "c":
    print("Average")
case "D", "d":
    print("Below Average")
case "F", "f":
    print("Poor")
default:
    print("Invalid grade")
}

var trafficLight: String = "red"

switch trafficLight {
case "red":
    print("Stop")
case "yellow":
    print("Get Ready")
case "green":
    print("Go")
default:
    print("Invalid color")
}
